<script src="{{URL::asset('assets/js/jquery-3.4.1.min.js')}}"></script>
<script src="{{URL::asset('assets/js/popper.min.js')}}"></script>
<script src="{{URL::asset('assets/js/bootstrap.min.js')}}"></script>
<script src="{{URL::asset('assets/js/amcharts-core.min.js')}}"></script>
<script src="{{URL::asset('assets/js/amcharts.min.js')}}"></script>
<script src="{{URL::asset('assets/js/custom.min.js')}}"></script>

@stack('js')
