<header class="ec-header">
    <!--Ec Header Top Start -->

    <!-- Ec Header Top  End -->
    <!-- Ec Header Bottom  Start -->
        <div class="container position-relative my-2">
            <div class="row">
                <div class="ec-flex justify-content-center">
                    <!-- Ec Header Logo Start -->
                    <div class="align-self-center">
                        <div class="header-logo m-0">
                            <a href="#"><img src="/assets/img/logo/mlogo.png" alt="Site Logo" /><img
                                    class="dark-logo" src="/assets/img/logo/mlogo.png" alt="Site Logo"
                                    style="display: none;" /></a>
                        </div>
                    </div>
                    <!-- Ec Header Logo End -->

                    <!-- Ec Header Search Start -->
                    {{-- <div class="align-self-center ec-header-search">
                        <div class="header-search">
                            <form class="ec-search-group-form" action="#">
                                <div class="ec-search-select-inner">
                                    <select name="ec-search-cat">
                                        <option selected disabled>All</option>
                                        <option value="principal">Principal</option>
                                        <option value="product">Product</option>
                                    </select>
                                </div>
                                <input class="form-control" placeholder="I’m searching for..." type="text">
                                <button class="search_submit" type="submit">Search <i
                                        class="fi-rr-search"></i></button>
                            </form>
                        </div>
                    </div> --}}
                    <!-- Ec Header Search End -->


                    <!-- Ec Header Button Start -->
                </div>
            </div>
        </div>
        <div style="background-color: #142F41; height:20px"></div>

    <!-- Ec Header Button End -->
    <!-- Header responsive Bottom  Start -->
    <!-- Header responsive Bottom  End -->
    <!-- EC Main Menu Start -->
    <!-- Ec Main Menu End -->
    <!-- ekka Mobile Menu Start -->
    <div id="ec-mobile-menu" class="ec-side-cart ec-mobile-menu">
        <div class="ec-menu-title">
            <span class="menu_title">My Menu</span>
            <button class="ec-close">×</button>
        </div>
        <div class="ec-menu-inner">
            <div class="ec-menu-content">
                <ul>
                    <li><a href="/">Home</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- ekka mobile Menu End -->
</header>
